<?php
session_start();

// Redirecionar para o painel de administrador
header("Location: admin_dashboard.php");
exit;
?> 